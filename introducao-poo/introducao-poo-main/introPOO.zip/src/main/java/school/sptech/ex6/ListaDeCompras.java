package school.sptech.ex6;

import java.util.ArrayList;
import java.util.List;

public class ListaDeCompras {

    String nomeLista;
    Integer capacidadeMaxima;
    List<String> itens = new ArrayList<>();

    void adicionarItem(String item) {
        if (capacidadeMaxima != null && itens.size() >= capacidadeMaxima) {
            return;
        }

        if (itens.contains(item)) {
            return;
        }

        itens.add(item);
    }

    Boolean removerItem(String item) {
        return itens.remove(item);
    }

    String obterItem(Integer posicao) {
        if (posicao == null || posicao < 0 || posicao >= itens.size()) {
            return null;
        }
        return itens.get(posicao);
    }

    Boolean substituirItem(Integer posicao, String novoItem) {
        if (posicao == null || posicao < 0 || posicao >= itens.size()) {
            return false;
        }

        if (itens.contains(novoItem)) {
            return false;
        }

        itens.set(posicao, novoItem);
        return true;
    }

    Integer calcularVagasRestantes() {
        if (capacidadeMaxima == null) {
            return 0;
        }
        return capacidadeMaxima - itens.size();
    }

    String removerItemNaPosicao(Integer posicao) {
        if (posicao == null || posicao < 0 || posicao >= itens.size()) {
            return null;
        }
        return itens.remove((int) posicao);
    }

    Integer removerItensDuplicados() {
        Integer quantidadeRemovida = 0;

        for (int i = 0; i < itens.size(); i++) {
            String itemAtual = itens.get(i);

            for (int j = i + 1; j < itens.size(); j++) {
                if (itens.get(j) != null && itens.get(j).equals(itemAtual)) {
                    itens.remove(j);
                    quantidadeRemovida++;
                    j--;
                }
            }
        }

        return quantidadeRemovida;
    }
}